#import "ViewController.h"
#include <dlfcn.h>

@implementation ViewController {
    void *handle;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];

    UIButton *injectButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [injectButton setTitle:@"Inject" forState:UIControlStateNormal];
    injectButton.frame = CGRectMake(100, 200, 200, 50);
    [injectButton addTarget:self action:@selector(injectDylib) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:injectButton];

    UIButton *stopButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [stopButton setTitle:@"Stop" forState:UIControlStateNormal];
    stopButton.frame = CGRectMake(100, 300, 200, 50);
    [stopButton addTarget:self action:@selector(unloadDylib) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:stopButton];
}

- (void)injectDylib {
    if (!handle) {
        NSString *path = [[NSBundle mainBundle] pathForResource:@"CuongNguyen" ofType:@"dylib"];
        handle = dlopen([path UTF8String], RTLD_NOW);
        if (handle) {
            NSLog(@"Dylib loaded!");
        } else {
            NSLog(@"Failed to load dylib: %s", dlerror());
        }
    }
}

- (void)unloadDylib {
    if (handle) {
        dlclose(handle);
        handle = NULL;
        NSLog(@"Dylib unloaded.");
    }
}

@end
